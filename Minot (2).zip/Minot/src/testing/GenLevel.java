package testing;

public class GenLevel {
	
	public static void level1(Block grid[][]){
		
	}

}
