package testing;

public class PaintExample {

	public static void main(String[] args) {
		System.out.printf(
				"xxxxxxxxxx\nx      xEx\nx      x x\nx      x x\nx      x x\nx      x x\nx      x x\nxxxxxxxx x\nxS   C   x\nxxxxxxxxxx\n");

		System.out.printf(
				"xxxxxxxxxx\nx      xEx\nx      x x\nx      x x\nx      x x\nx      x x\nx      x x\nxxxxxxxx x\nxS    C  x\nxxxxxxxxxx\n");

		System.out.printf(
				"xxxxxxxxxx\nx      xEx\nx      x x\nx      x x\nx      x x\nx      x x\nx      x x\nxxxxxxxx x\nxS     C x\nxxxxxxxxxx\n");

		System.out.printf(
				"xxxxxxxxxx\nx      xCx\nx      x x\nx      x x\nx      x x\nx      x x\nx      x x\nxxxxxxxx x\nxS       x\nxxxxxxxxxx\n");

		System.out.printf(
				"xxxxxxxxxx\nxSC     Ex\nxxDxxxxxxx\nxxxx     x\nx        x\nx        x\nx        x\nx        x\nx        x\nxxxxxxxxxx\n");

		System.out.printf(
				"xxxxxxxxxx\nxSD C   Ex\nxx xxxxxxx\nxxxx     x\nx        x\nx        x\nx        x\nx        x\nx        x\nxxxxxxxxxx\n");

	}
}
